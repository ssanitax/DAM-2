"""
ACCESO ALEATORIO A FICHEROS
---------------------------
Python no tiene una clase nativa "RandomAccessFile" como otros
lenguajes. Simulamos el acceso aleatorio combinando open() con
seek() (mover el puntero) y tell() (saber dónde está el puntero).

Truco clave: si cada registro ocupa SIEMPRE el mismo número de
bytes (longitud fija), podemos calcular a qué posición saltar
con una simple multiplicación: posición = numero_registro * tamaño_registro.
"""

NOMBRE_FICHERO = "alumnos_aleatorio.txt"
TAMANO_REGISTRO = 20  # bytes que ocupa cada línea, incluido el relleno y el \n


def escribir_registros_tamano_fijo():
    """Crea un fichero donde cada registro mide exactamente TAMANO_REGISTRO bytes."""
    print("--- Creando fichero con registros de tamaño fijo ---")
    alumnos = ["Ana Garcia", "Luis Perez", "Marta Ruiz", "Diego Torres"]

    fichero = open(NOMBRE_FICHERO, "w")
    for nombre in alumnos:
        # ljust() rellena con espacios a la derecha hasta completar el ancho
        linea = nombre.ljust(TAMANO_REGISTRO - 1) + "\n"
        fichero.write(linea)
    fichero.close()
    print(f"Se han escrito {len(alumnos)} registros de {TAMANO_REGISTRO} bytes cada uno.\n")


def leer_registro_directo(numero_registro):
    """Salta directamente al registro N sin leer los anteriores."""
    print(f"--- Accediendo directamente al registro nº {numero_registro} ---")
    fichero = open(NOMBRE_FICHERO, "r")

    posicion = numero_registro * TAMANO_REGISTRO
    fichero.seek(posicion)                 # saltamos directamente ahí
    print(f"Puntero movido a la posición (byte): {fichero.tell()}")

    linea = fichero.readline()
    fichero.close()
    print(f"Contenido leído: '{linea.strip()}'\n")


def modificar_registro_directo(numero_registro, nombre_nuevo):
    """Sobrescribe un registro concreto sin tocar los demás."""
    print(f"--- Modificando el registro nº {numero_registro} ---")
    # Modo 'r+' permite leer Y escribir sin borrar el fichero
    fichero = open(NOMBRE_FICHERO, "r+")

    posicion = numero_registro * TAMANO_REGISTRO
    fichero.seek(posicion)

    linea_nueva = nombre_nuevo.ljust(TAMANO_REGISTRO - 1) + "\n"
    fichero.write(linea_nueva)
    fichero.close()
    print(f"Registro sustituido por: '{nombre_nuevo}'\n")


def main():
    escribir_registros_tamano_fijo()

    # Acceso directo: leemos el registro 2 (Marta) SIN pasar por el 0 y el 1
    leer_registro_directo(2)

    # Modificamos el registro 0 (Ana) directamente
    modificar_registro_directo(0, "Sofia Diaz")

    # Comprobamos el cambio leyendo de nuevo ese mismo registro
    leer_registro_directo(0)

    # Y confirmamos que el resto del fichero sigue intacto
    leer_registro_directo(1)
    leer_registro_directo(2)
    leer_registro_directo(3)


if __name__ == "__main__":
    main()
