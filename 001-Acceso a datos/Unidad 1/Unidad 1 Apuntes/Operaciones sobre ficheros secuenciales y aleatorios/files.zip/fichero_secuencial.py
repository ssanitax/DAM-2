"""
ACCESO SECUENCIAL A FICHEROS
----------------------------
En un fichero secuencial, los datos se leen o escriben en orden,
del principio al final. No podemos "saltar" directamente a un
registro concreto: para llegar al quinto, antes hay que pasar
por el primero, el segundo, el tercero y el cuarto.
"""

NOMBRE_FICHERO = "alumnos_secuencial.txt"


def escribir_varios_alumnos():
    """Escribe varias líneas de una sola vez con writelines()."""
    print("--- Escribiendo alumnos (writelines) ---")
    alumnos = [
        "Ana Garcia,8.5\n",
        "Luis Perez,7.2\n",
        "Marta Ruiz,9.1\n",
    ]
    fichero = open(NOMBRE_FICHERO, "w")
    fichero.writelines(alumnos)
    fichero.close()
    print(f"Se han escrito {len(alumnos)} alumnos en '{NOMBRE_FICHERO}'.\n")


def anadir_un_alumno():
    """Añade una línea más usando write(), sin borrar lo anterior."""
    print("--- Añadiendo un alumno más (write + modo 'a') ---")
    fichero = open(NOMBRE_FICHERO, "a")
    fichero.write("Diego Torres,6.8\n")
    fichero.close()
    print("Alumno añadido.\n")


def leer_todo_de_golpe():
    """Lee el contenido completo del fichero con read()."""
    print("--- Leyendo todo el fichero de golpe (read) ---")
    fichero = open(NOMBRE_FICHERO, "r")
    contenido = fichero.read()
    fichero.close()
    print(contenido)


def leer_linea_a_linea():
    """Recorre el fichero en orden, una línea cada vez (readline)."""
    print("--- Leyendo línea a línea, en orden (readline) ---")
    fichero = open(NOMBRE_FICHERO, "r")
    numero_linea = 1
    linea = fichero.readline()
    while linea != "":
        print(f"Línea {numero_linea}: {linea.strip()}")
        numero_linea += 1
        linea = fichero.readline()
    fichero.close()
    print()


def main():
    escribir_varios_alumnos()
    anadir_un_alumno()
    leer_todo_de_golpe()
    leer_linea_a_linea()


if __name__ == "__main__":
    main()
