Arquitectura cliente/servidor

