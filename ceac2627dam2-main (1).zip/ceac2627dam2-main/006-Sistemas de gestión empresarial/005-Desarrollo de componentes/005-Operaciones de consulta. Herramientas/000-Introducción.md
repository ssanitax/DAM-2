# Operaciones de consulta. Herramientas

