# Manejo de conectores

