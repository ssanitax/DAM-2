# Arquitectura del API utilizado

