# Procesamiento de objetos multimedia

