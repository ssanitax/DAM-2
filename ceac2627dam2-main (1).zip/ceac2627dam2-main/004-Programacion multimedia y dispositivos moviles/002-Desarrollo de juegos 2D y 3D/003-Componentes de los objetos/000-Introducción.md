# Componentes de los objetos

