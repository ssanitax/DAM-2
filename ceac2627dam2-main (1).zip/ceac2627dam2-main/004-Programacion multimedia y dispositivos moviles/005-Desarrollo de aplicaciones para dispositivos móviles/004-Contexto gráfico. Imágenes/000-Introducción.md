# Contexto gráfico. Imágenes

