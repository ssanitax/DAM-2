# Conectividad. Tipos.

