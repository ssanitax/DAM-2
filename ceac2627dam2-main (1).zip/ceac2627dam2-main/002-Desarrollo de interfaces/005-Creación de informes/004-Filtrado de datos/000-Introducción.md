# Filtrado de datos

